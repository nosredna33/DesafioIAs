# Estrutura do Projeto
	src/
	 ├─ main/
	 │	├─ java/
	 │	│	└─ br/
	 │	│		└─ com/
	 │	│			└─ megapowerx/                               → br/com/megapowerx/ (classes Java)
	 │	│				├─ Aposta.java                           
	 │	│				├─ ApostaCandidata.java                  
	 │	│				├─ Estrategia.java                       
	 │	│				├─ filtros/                              
	 │	│				│   ├─ FiltraBordasCentro.java           
	 │	│				│   ├─ FiltraDireitaEsquerda.java        
	 │	│				│   ├─ FiltraParImpar.java               
	 │	│				│   ├─ FiltraPrimos.java                 
	 │	│				│   ├─ FiltraSequenciasConsecutivas.java 
	 │	│				│   ├─ FiltraSomaTotal.java              
	 │	│				│   ├─ FiltraSuperiorInferior.java       
	 │	│				│   ├─ FiltraDistribuicaoColunas.java    
	 │	│				│   └─ ...	                             
	 │	│				└─ utils/                                
	 │	│					└─ ...                               → caso queira classes utilitárias futuras)
	 │	└─ resources/                                            → recursos do projeto (se houver)
	 ├─ test/                                                    
	 │	└─ java/                                                 → testes (JUnit, adicionar depois)