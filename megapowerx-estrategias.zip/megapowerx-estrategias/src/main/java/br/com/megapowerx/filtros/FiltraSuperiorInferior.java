package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;

import java.util.List;

/**
 * Filtra pela contagem de dezenas na parte inferior da cartela (31 a 60) 
 * ou superior (1 a 30).
 */
public class FiltraSuperiorInferior extends Estrategia {

    private static final String NAME = "Filtro Superior/Inferior";
    private static final String DESCRIPTION = "Filtra dezenas da metade superior (31-60)";
    private static final String TAG_ID = "FiltroSuperiorInferior";

    public FiltraSuperiorInferior() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraSuperiorInferior(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

	/**
	 *  Por exemplo poderia se buscar no banco a quantida de jogos no intervalo 
	 *  do filtro e substituir aqui! Assim como a mádia, min, max e desvio das somas
	 *  
	 *  Entretantpo, para este filtro não se aplica!
	 */
    @Override
    protected void init() {
        calcMin = 0.0;
        calcAvg = 3.0;
        calcMax = 6.0;
        calcStdV = 1.0;
    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();

        long count = dezenas.stream()
            .filter(n -> n <= 30)
            .count();

        aposta.setRanking(isDentroDosLimites(count) ? addRankIfTrue : addRankIfFalse);
    }

}
