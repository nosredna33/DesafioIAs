package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;
import java.util.List;

/**
 * Filtra dezenas que estão nas bordas ou no centro da cartela.
 * Consideradas como bordas as dezenas:
 * 1 a 10, 11, 21, 31, 41, 20, 30, 40, 50, 51 a 60.
 */
public class FiltraBordasCentro extends Estrategia {

    private static final String NAME = "Filtro Bordas e Centro";
    private static final String DESCRIPTION = "Filtra p/ dezenas na bordas :1–10,11,21,31,41,20,30,40,50,51–60.";
    private static final String TAG_ID = "FiltroBordasCentro";
	
    // Constantes para cálculos usadas no init()
    private static final double QTD_BORDAS = 20.0;
    private static final double MIN_BORDA = 1.0;
    private static final double MEDIA_BORDAS = 20.5;
    private static final double MAX_BORDA = 60.0;
    private static final double DESVIO_PADRAO = 16.0;
	
    public FiltraBordasCentro() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraBordasCentro(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    @Override
    protected void init() {
        this.calcQtd  = QTD_BORDAS;       // Qtd de números nas bordas
        this.calcMin  = MIN_BORDA;        // O Menor número nas bordas
        this.calcAvg  = MEDIA_BORDAS;     // A média dos números nas bordas
        this.calcMax  = MAX_BORDA;        // O Maior número nas bordas
        this.calcStdV = DESVIO_PADRAO;    // O Desvio Padrão Médio dos números nas bordas
    }
	
    private boolean isBorda(int dezena) {
        if (dezena >= 1 && dezena <= 10) return true;
        if (dezena >= 51 && dezena <= 60) return true;
        return dezena == 11 || dezena == 21 || dezena == 31 || dezena == 41
            || dezena == 20 || dezena == 30 || dezena == 40 || dezena == 50;
    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();
		// Um jeito
        long countBorda = dezenas.stream().filter(this::isBorda).count();
        aposta.addRanking(isDentroDosLimites(countBorda) ? addRankIfTrue : addRankIfFalse);
		
		/* Outro jeito
        long count = dezenas.stream().filter(n ->
            n <= 10 || n >= 51 || n % 10 == 1 || n % 10 == 0
        ).count();		
		aposta.addRanking(isDentroDosLimites(count) ? addRankIfTrue : addRankIfFalse);
		*/
    }
}
