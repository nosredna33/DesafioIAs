package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;

import java.util.List;

/**
 * Filtra sequências consecutivas longas na aposta.
 */
public class FiltraSequenciasConsecutivas extends Estrategia {

    private static final String NAME = "Filtro Sequências Consecutivas";
    private static final String DESCRIPTION = "Evita sequências muito longas de dezenas consecutivas.";
    private static final String TAG_ID = "FiltroSeqConsecutiva";

    private int maxSequenciaPermitida = 3;

    public FiltraSequenciasConsecutivas() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraSequenciasConsecutivas(int maxSequenciaPermitida, float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

	/**
	 *  Por exemplo poderia se buscar no banco a quantida de jogos com números 
	 *  consecutivos para o intervalo do filtro e substituir aqui!
	 *  
	 *  Entretantpo, para este filtro não se aplica!
	 */
    @Override
    protected void init() {
		calcQtd  = 0.0;  // Qtd de de ocorrências na faixa
        calcMin  = 1.0;  // O Menor número primo 
        calcAvg  = 2.0;  // A média dos números primos
        calcMax  = 3.0;  // O Maior número primo
        calcStdV = 4.0;  // O Desvio Padrão Médio dos números primos

    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();

        int maiorSequencia = 1;
        int atualSequencia = 1;

        for (int i = 1; i < dezenas.size(); i++) {
            if (dezenas.get(i) == dezenas.get(i - 1) + 1) {
                atualSequencia++;
                if (atualSequencia > maiorSequencia) maiorSequencia = atualSequencia;
            } else {
                atualSequencia = 1;
            }
        }

        aposta.setRanking(isDentroDosLimites(maiorSequencia) && maiorSequencia <= maxSequenciaPermitida ? addRankIfTrue : addRankIfFalse);
    }
}
