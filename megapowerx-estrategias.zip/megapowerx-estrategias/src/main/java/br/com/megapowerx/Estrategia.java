import java.util.Observable;
import br.com.megapowerx.ApostaCandidata;

public abstract class Estrategia extends Observable {
    // Constantes específicas da subclasse, 
	// Parâmetros configuráveis na construção da instância
	protected String NAME = null;
	protected String DESCRIPTION = null;
	protected String TAG_ID = null;	 
	
    protected float addRankIfTrue;
    protected float addRankIfFalse;
    protected Double minLimit;
    protected Double maxLimit;

    // Valores calculados durante init()
	protected Double calcQtd   = null;
    protected Double calcMin   = null;
    protected Double calcAvg   = null;
    protected Double calcMax   = null;
    protected Double calcStdV  = null;

    // Construtores
    public Estrategia() {
        this(100.0f, -80.0f, null, null);
    }

    public Estrategia(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        this.addRankIfTrue = addRankIfTrue;
        this.addRankIfFalse = addRankIfFalse;
        this.minLimit = minLimit;
        this.maxLimit = maxLimit;
        init();
    }

    // Método abstrato que inicializa os valores derivados
    protected abstract void init();

    // Novo método abstrato obrigatório para processar a aposta
    public abstract void process(ApostaCandidata aposta);

    // Getters
    public float getAddRankIfTrue() { return addRankIfTrue; }
    public float getAddRankIfFalse() { return addRankIfFalse; }
    public Double getMinLimit() { return minLimit; }
    public Double getMaxLimit() { return maxLimit; }
    public Double getCalcMin() { return calcMin; }
    public Double getCalcAvg() { return calcAvg; }
    public Double getCalcMax() { return calcMax; }
    public Double getCalcStdV() { return calcStdV; }
    public String getName() { return NAME; }
    public String getDescription() { return DESCRIPTION; }
    public String getUniqueTagId() { return TAG_ID; }
    public String setNAME (final String NAME) { return this.NAME = NAME; }
    public String setDESCRIPTION (final String DESCRIPTION) { return this.DESCRIPTION = DESCRIPTION; }
    public String setTAG_ID (final String TAG_ID) { return this.TAG_ID = TAG_ID; }

    // equals e hashCode baseados no uniqueTagId (case-insensitive)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Estrategia that = (Estrategia) obj;
        return getUniqueTagId() != null && getUniqueTagId().equalsIgnoreCase(that.getUniqueTagId());
    }

    @Override
    public int hashCode() {
        return getUniqueTagId() == null ? 0 : getUniqueTagId().toLowerCase().hashCode();
    }

    @Override
    public String toString() {
        return "Estrategia{" +
            "name='" + getName() + '\'' +
            ", description='" + getDescription() + '\'' +
            ", uniqueTagId='" + getUniqueTagId() + '\'' +
            ", addRankIfTrue=" + addRankIfTrue +
            ", addRankIfFalse=" + addRankIfFalse +
            ", minLimit=" + minLimit +
            ", maxLimit=" + maxLimit +
            ", calcMin=" + calcMin +
            ", calcAvg=" + calcAvg +
            ", calcMax=" + calcMax +
            ", calcStdV=" + calcStdV +
            '}';
    }
}
