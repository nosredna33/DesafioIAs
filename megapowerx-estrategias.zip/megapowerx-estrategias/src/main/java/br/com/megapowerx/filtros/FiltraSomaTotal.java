package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;

import java.util.List;

/**
 * Filtra apostas pela soma total das dezenas.
 */
public class FiltraSomaTotal extends Estrategia {

    private static final String NAME = "Filtro Soma Dezenas";
    private static final String DESCRIPTION = "Filtra a soma das dezenas na aposta.";
    private static final String TAG_ID = "FiltroSomaDezenas";

    public FiltraSomaTotal() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraSomaTotal(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

	/**
	 *  Por exemplo poderia se buscar no banco a quantida de jogos no intervalo 
	 *  do filtro e substituir aqui! Assim como a mádia, min, max e desvio das somas
	 *  
	 *  Entretantpo, para este filtro não se aplica!
	 */
    @Override
    protected void init() {
        calcMin = 100.0;
        calcAvg = 150.0;
        calcMax = 300.0;
        calcStdV = 50.0;
    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();
        int soma = dezenas.stream().mapToInt(Integer::intValue).sum();

        aposta.setRanking(isDentroDosLimites(soma) ? addRankIfTrue : addRankIfFalse);
    }

}
