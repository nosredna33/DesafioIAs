package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;
import java.util.List;

/**
 * Filtra a quantidade de dezenas pares.
 */
public class FiltraParImpar extends Estrategia {

    private static final String NAME = "Filtro Par/Ímpar";
    private static final String DESCRIPTION = "Filtra por quantidade de dezenas pares";
    private static final String TAG_ID = "FiltroDezenasParImpar";

    public FiltraParImpar() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraParImpar(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    @Override
    protected void init() {
		calcQtd = 30.0;   // Qtd de números pares
        calcMin = 2.0;    // O Menor número par 
        calcAvg = 31.0;   // A média dos números pares
        calcMax = 60.0;   // O Maior número par
        calcStdV = 15.0;  // O Desvio Padrão Médio dos números pares
    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();
        long count = dezenas.stream().filter(n -> n % 2 == 0).count();
        aposta.setRanking(isDentroDosLimites(count) ? addRankIfTrue : addRankIfFalse);
    }
}
