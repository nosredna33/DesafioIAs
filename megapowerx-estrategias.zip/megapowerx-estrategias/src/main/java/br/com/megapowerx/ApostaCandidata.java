package br.com.megapowerx;

/**
 * Representa uma aposta concreta com string e ranking,
 * herdando comportamento de Aposta abstrata.
 */
public class ApostaCandidata extends Aposta {

    public ApostaCandidata() {
        super();
    }

    public ApostaCandidata(String aposta) {
        super(aposta);
    }
	
	public ApostaCandidata(String aposta, Double ranking) {
		super (aposta, ranking);
	}
	
    @Override
    public String toString() {
        return "[CANDIDATA] Aposta: " + aposta + ", Ranking: " + ranking;
    }

    @Override
    public String toJson() {
        return String.format("{\"tipo\":\"candidata\",\"aposta\":\"%s\",\"ranking\":%.2f}",
                aposta, ranking != null ? ranking : 0.0);
    }
	
	// Builder estático
    public static class Builder {
        private String aposta;
        private Double ranking;

        public Builder setAposta(String aposta) {
            this.aposta = aposta;
            return this;
        }

        public Builder setRanking(Double ranking) {
            this.ranking = ranking;
            return this;
        }

        public ApostaCandidata build() {
            return new ApostaCandidata(aposta, ranking);
        }
    }
}
