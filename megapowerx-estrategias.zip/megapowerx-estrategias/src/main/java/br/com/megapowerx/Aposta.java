package br.com.megapowerx;

import java.util.*;
import java.util.stream.Collectors;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Classe abstrata que representa uma aposta, contendo os métodos
 * básicos para manipulação, parse de dezenas e identificação lexicográfica.
 * Também implementa Comparable para ordenação por ranking.
 * 
 * Subclasses devem implementar suas regras específicas e lógica de ranking.
 */
public abstract class Aposta implements Comparable<Aposta> {

    protected String aposta  = null;
    protected Double ranking = null;

    public Aposta(String aposta) {
        this.aposta = aposta;
		this.ranking = 0.0f;
    }
	
	public Aposta(String aposta, Double ranking) {
		this.aposta  = aposta;
		this.ranking = ranking;
	}
	
    /**
     * Retorna a string da aposta, ex: "01 02 03 04 05 06".
     */
    public String getAposta() {
        return aposta;
    }

    public void setAposta(String aposta) {
        this.aposta = aposta;
    }

    public Double getRanking() {
        return ranking;
    }

    public void setRanking(Double ranking) {
        this.ranking = ranking;
    }
	
    public void addRanking(Double ranking) {
        this.ranking += ranking;
    }
	
    /**
     * Faz o parse da string de aposta em uma lista ordenada de inteiros.
     * @return List<Integer> com as dezenas ordenadas.
     */
    public List<Integer> parseDezenas() {
        return Arrays.stream(aposta.trim().split("\\D+"))
                     .map(Integer::parseInt)
                     .sorted()
                     .collect(Collectors.toList());
    }

    /**
     * Calcula o ID lexicográfico da aposta entre todas as combinações possíveis.
     * 
     * @return long número único representando a posição lexicográfica.
     */
    public long getIdLexicografico() {
        List<Integer> dezenas = parseDezenas();
        long id = 0;
        int k = dezenas.size();

        for (int i = 0; i < k; i++) {
            int d = dezenas.get(i);
            int anterior = (i == 0) ? 0 : dezenas.get(i - 1);
            for (int j = anterior + 1; j < d; j++) {
                id += combinatoria(60 - j, k - i - 1);
            }
        }
        return id + 1;
    }

    /**
     * Calcula combinação n sobre k (n choose k).
     * @param n total de elementos
     * @param k quantidade escolhida
     * @return número de combinações
     */
    private long combinatoria(int n, int k) {
        if (k < 0 || k > n) return 0;
        if (k == 0 || k == n) return 1;
        long res = 1;
        for (int i = 1; i <= k; i++) {
            res = res * (n - i + 1) / i;
        }
        return res;
    }

    /**
     * Retorna o JSON da aposta e ranking.
     * @return String JSON
     */
    public String toJson() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(this);
        } catch (Exception e) {
            return "{\"aposta\":\"" + aposta + "\",\"ranking\":" + ranking + "}";
        }
    }

    @Override
    public String toString() {
        return "Aposta: " + aposta + " | Ranking: " + ranking + " | ID-Lex: " + getIdLexicografico();
    }

    @Override
    public int compareTo(Aposta outra) {
        return Double.compare(this.ranking, outra.ranking);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Aposta)) return false;
        Aposta outra = (Aposta) obj;
        return Objects.equals(this.aposta, outra.aposta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(aposta);
    }
}
