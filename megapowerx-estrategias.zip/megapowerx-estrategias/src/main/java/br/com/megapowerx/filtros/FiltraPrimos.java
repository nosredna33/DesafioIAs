package br.com.megapowerx.filtros;

import br.com.megapowerx.ApostaCandidata;
import br.com.megapowerx.Estrategia;

import java.util.List;

/**
 * Filtra dezenas que são números primos.
 * Implementa estratégia de filtro baseada em propriedades matemáticas 
 * de números primos.
 */ 
public class FiltraPrimos extends Estrategia {

    private static final String NAME = "Filtro Primos";
    private static final String DESCRIPTION = "Filtra quantidade de dezenas que são números primos.";
    private static final String TAG_ID = "FiltroPrimos";

    public FiltraPrimos() {
        super();
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public FiltraPrimos(float addRankIfTrue, float addRankIfFalse, Double minLimit, Double maxLimit) {
        super(addRankIfTrue, addRankIfFalse, minLimit, maxLimit);
        setNAME (NAME);
        setDESCRIPTION (DESCRIPTION);
        setTAG_ID (TAG_ID);
		init();
    }

    public static boolean ehPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
	
    /**
     * Verifica se um número é primo (otimizado)
     */
    public static boolean ehPrimo2(int numero) {
        if (numero <= 1) return false;
        if (numero <= 3) return true;
        if (numero % 2 == 0 || numero % 3 == 0) return false;
        
        for (int i = 5; i * i <= numero; i += 6) {
            if (numero % i == 0 || numero % (i + 2) == 0) 
                return false;
        }
        return true;
    }
	
    @Override
    protected void init() {
		calcQtd  = 17.0;   // Qtd de números primos
        calcMin  = 2.0;    // O Menor número primo 
        calcAvg  = 25.88;  // A média dos números primos
        calcMax  = 59.0;   // O Maior número primo
        calcStdV = 15.64;  // O Desvio Padrão Médio dos números primos
    }

    @Override
    public void process(ApostaCandidata aposta) {
        List<Integer> dezenas = aposta.parseDezenas();
        long count = dezenas.stream().filter(FiltraPrimos::ehPrimo).count();
        aposta.setRanking(isDentroDosLimites(count) ? addRankIfTrue : addRankIfFalse);
    }

}
